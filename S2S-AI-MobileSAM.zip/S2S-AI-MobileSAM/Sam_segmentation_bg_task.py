from qgis.PyQt.QtGui import QIcon

from .resources import *

from timeit import default_timer as timer
from qgis.core import (
    QgsApplication, QgsTask,  Qgis
    )
from qgis.core import *
from PyQt5.QtCore import QObject,QProcess, QProcessEnvironment
from PyQt5.QtWidgets import QProgressBar, QPushButton, QMessageBox
import subprocess
import shlex
import os
from qgis.utils import iface
import platform

class Sam_segmentation_bg_task(QObject):

    def __init__(self):
        super(Sam_segmentation_bg_task, self).__init__()
        self.state = "Stop"
        self.iface = iface

    def newTask(self, main_class):
        self.main_class = main_class
        self.msg = iface.messageBar().createMessage('Action', 'Starting SAM')
        self.prog = QProgressBar(self.msg)
        self.btn_cancel = QPushButton(self.msg)
        self.btn_cancel.setText('Cancel Task')
        self.btn_cancel.clicked.connect(self.cancelTask)
        self.msg.layout().addWidget(self.prog)
        self.msg.layout().addWidget(self.btn_cancel)

        is_windows = platform.system() == "Windows"
        print("is_windows", is_windows)

        iface.messageBar().pushWidget(self.msg, Qgis.Info)
        self.prog.setValue(30)

        conda_env_path, conda_python, sam_script, model_path = self.fetch_file_locations()
        print("conda_env_path", conda_env_path, "conda_python:", conda_python, "sam_script:", sam_script, "model_path:", model_path)
        
        self.process = QProcess()            
        env = QProcessEnvironment.systemEnvironment()

        existing_path = env.value("PATH")
        if is_windows:
            new_path = conda_env_path + r"\Library\bin;" + conda_env_path + r"\Scripts;" + conda_env_path + ";" + existing_path
            env.insert("PYTHONHOME", conda_env_path)
            env.insert("PYTHONPATH", "")
        else:
            new_path = conda_env_path + "/bin:" + existing_path
            env.remove("PYTHONHOME") 
            env.remove("PYTHONPATH")
        
        env.insert("PATH", new_path)
        env.insert("CONDA_PREFIX", conda_env_path)
        self.process.setProcessEnvironment(env)

        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.process_finished)

        self.process.start(conda_python, [sam_script, model_path])

    def fetch_file_locations(self):
        full_path = os.path.dirname(os.path.realpath(__file__))
        print(full_path)

        path_env = ''
        if os.path.isfile(self.main_class.file_name_venv):
            print(self.main_class.file_name_venv, "exist")
            with open(self.main_class.file_name_venv, "r") as f:
                path_env = f.readline().strip()
        else:
            print(self.main_class.file_name_venv, "no exist")

        full_path_weight = ''
        if os.path.isfile(self.main_class.file_name_weight):
            with open(self.main_class.file_name_weight, "r") as f:
                full_path_weight = f.readline().strip()

        file_path = os.path.join(full_path,'sam_segmentation_qgis_server.py')

        tmp = path_env.rsplit("\\", 1)
        if len(tmp) > 1:
            conda_env_path = tmp[0]
        else:
            conda_env_path = path_env.rsplit("/",1)[0]

        return conda_env_path, path_env, file_path, full_path_weight

    def handle_stdout(self):
        output = self.process.readAllStandardOutput().data().decode()
        print("STDOUT:", output.strip())

        if "Python executable" in output:
            self.prog.setValue(60)            

        if "sam started correctly" in output:
            self.prog.setValue(100)
            iface.messageBar().popWidget(self.msg)
            iface.mainWindow().statusBar().showMessage("SAM started correctly")
            self.main_class.actions[1].setIcon(QIcon(":images/themes/default/repositoryConnected.svg"))
            self.main_class.actions[1].setText(self.main_class.tr(u'Stop SAM'))
            self.state = "Started"

    def handle_stderr(self):
        error = self.process.readAllStandardError().data().decode()
        print("STDERR:", error.strip())

    def process_finished(self):
        print("External SAM script finished.")

    def cancelTask(self):
        if hasattr(self, 'process') and self.process is not None:
            self.process.kill()
            self.state = "Stop"

            self.main_class.actions[1].setIcon(QIcon(":images/themes/default/repositoryUnavailable.svg"))
            self.main_class.actions[1].setText(self.main_class.tr(u'Start Mobile SAM'))

            try:
                if self.msg:
                    iface.messageBar().popWidget(self.msg)
                    self.msg = None
            except RuntimeError as e:
                print("Tried to pop already deleted message bar item:", e)

            iface.mainWindow().statusBar().showMessage("SAM process killed")
        else:
            QMessageBox.information(None, "Error", "No SAM process running.")
