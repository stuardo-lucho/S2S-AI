import os
import torch

from mobile_sam import sam_model_registry, SamAutomaticMaskGenerator, SamPredictor
import cv2
import sys
import numpy as np

print("Python executable:", sys.executable)
print("PATH:", os.environ.get("PATH"))

full_path = os.path.dirname(os.path.realpath(__file__))
print(full_path)
sys.stdout.flush()
sys.stderr.flush()

CHECKPOINT_PATH = sys.argv[1]
MODEL_TYPE = "vit_t"

print(CHECKPOINT_PATH, "; exist:", os.path.isfile(CHECKPOINT_PATH))
sys.stdout.flush()
sys.stderr.flush()

DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

print("device:", DEVICE)
sys.stdout.flush()
sys.stderr.flush()

sam = sam_model_registry[MODEL_TYPE](checkpoint=CHECKPOINT_PATH)
sam.to(device=DEVICE)
sam.eval()

print("sam started correctly")
sys.stdout.flush()
sys.stderr.flush()

from flask import Flask,request, jsonify
from pycocotools import mask as mask_utils
from json import JSONEncoder
import json
import gc
from timeit import default_timer as timer

class NumpyArrayEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return JSONEncoder.default(self, obj)
    
app = Flask(__name__)

@app.route("/")
def hello():
    start_time = timer()
    
    print("get request")
    scPath = request.args.get('scPath')
    points_per_side = int(request.args.get('ppp'))
    print("scPath:", scPath, "| points_per_side:", points_per_side)

    if "nt" in os.name:
        image_bgr = cv2.imdecode(np.fromfile(scPath, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    else:
        image_bgr = cv2.imread(scPath)
    image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    max_attempts = 6
    resize_factor = 0.75
    attempt = 0

    while attempt < max_attempts:
        try:
            print(f"Attempt {attempt+1}: Generating masks with ppp={points_per_side}, image shape={image_rgb.shape}")
            mask_generator = SamAutomaticMaskGenerator(model=sam, points_per_side=int(points_per_side))
            sam_result = mask_generator.generate(image_rgb)
            break  # Success
        except torch.cuda.OutOfMemoryError as e:
            print("CUDA OOM Error: ", e)
            torch.cuda.empty_cache()
            gc.collect()

            if attempt < 3:
                image_bgr = cv2.resize(image_bgr, None, fx=resize_factor, fy=resize_factor, interpolation=cv2.INTER_AREA)
                image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
                print(f"Image resized to {image_rgb.shape}")
            else:
                points_per_side = max(8, points_per_side // 2)
                print(f"Reducing points_per_side to {points_per_side}")

            attempt += 1

    else:
        raise RuntimeError("Failed to generate SAM masks after multiple attempts.")

    print("sam result:",timer()-start_time)

    start_time = timer()

    masks = [mask['segmentation'] for mask in sorted(sam_result, key=lambda x: x['area'], reverse=True)]

    all_contours = []
    for i,m in enumerate(masks):
        if isinstance(m, np.ndarray) and m.dtype == bool:
            m = mask_utils.encode(np.asfortranarray(m))
        elif isinstance(m, dict) and 'counts' in m and 'size' in m:
            pass  # Already in RLE format
        else:
            print("Invalid segmentation format:", m)
            continue
        
        mask = mask_utils.decode(m)
        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        contours = [np.squeeze(contour) for contour in contours]
        contours = [np.atleast_2d(contour) for contour in contours]
        all_contours.append(contours)

    numpyData = {"array": all_contours}
    encodedNumpyData = json.dumps(numpyData, cls=NumpyArrayEncoder)

    response = app.response_class(
        response=encodedNumpyData,
        status=200,
        mimetype='application/json'
    )
    return response

@app.route("/test")
def test():
    return {
        "server": "ok",
    }

app.run(host="0.0.0.0",port=5001)
