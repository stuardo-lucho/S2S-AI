# Initialize Qt resources from file resources.py
from .resources import *

from qgis.core import *
from PyQt5.QtCore import QObject
from PyQt5 import QtCore, QtGui, QtWidgets
import os
from os.path import expanduser


class Config_for_SAM(QObject):

    def open_dlg_window(self, main_class):

        self.main_class = main_class
        self.dlg = QtWidgets.QDialog()
        self.dlg.setObjectName("Dialog")
        self.dlg.resize(400, 230)
        self.dlg.setWindowTitle("Configurations for SAM")

        self.buttonBox = QtWidgets.QDialogButtonBox(self.dlg)
        self.buttonBox.setGeometry(QtCore.QRect(30, 190, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")

        self.label = QtWidgets.QLabel(self.dlg)
        self.label.setGeometry(QtCore.QRect(30, 30, 47, 13))
        self.label.setObjectName("label")
        self.label.setText("Pt File:")
        self.lineEdit_pth = QtWidgets.QLineEdit(self.dlg)
        self.lineEdit_pth.setGeometry(QtCore.QRect(30, 50, 301, 20))
        self.lineEdit_pth.setObjectName("lineEdit")
        self.pushButton = QtWidgets.QPushButton(self.dlg)
        self.pushButton.setGeometry(QtCore.QRect(340, 50, 41, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.setText("...")

        self.label_2 = QtWidgets.QLabel(self.dlg)
        self.label_2.setGeometry(QtCore.QRect(30, 90, 131, 16))
        self.label_2.setObjectName("label_2")
        self.label_2.setText("Conda Environment path:")
        self.lineEdit_conda = QtWidgets.QLineEdit(self.dlg)
        self.lineEdit_conda.setGeometry(QtCore.QRect(30, 110, 351, 20))
        self.lineEdit_conda.setObjectName("lineEdit_2")

        self.buttonBox.accepted.connect(self.btn_save) 
        self.buttonBox.rejected.connect(self.dlg.reject) 
        self.pushButton.clicked.connect(self.btn_select_file)

        if os.path.isfile(self.main_class.file_name_weight):
            f = open(self.main_class.file_name_weight, "r")
            self.full_path_weight = f.readline()
            self.lineEdit_pth.setText(self.full_path_weight)

        if os.path.isfile(self.main_class.file_name_venv):
            f = open(self.main_class.file_name_venv, "r")
            self.full_path_venv = f.readline()
            self.lineEdit_conda.setText(self.full_path_venv)

        self.dlg.exec_()



    def btn_save(self):
        f = open(self.main_class.file_name_weight, "w")
        f.write(self.lineEdit_pth.text())
        f.close()

        f = open(self.main_class.file_name_venv, "w")
        f.write(self.lineEdit_conda.text())
        f.close()
        self.dlg.close()


    def btn_select_file(self):
        qfd = QtWidgets.QFileDialog()
        f, _ = QtWidgets.QFileDialog.getOpenFileName(qfd, caption="Select a pt file", 
                                                     directory=".", filter="*.pt")
        self.lineEdit_pth.setText(f)
